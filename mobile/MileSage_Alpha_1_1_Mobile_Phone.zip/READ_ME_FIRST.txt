MileSage Alpha 1.1 — SAMSUNG PHONE INSTALLATION
13 November 2026

THIS IS A MOBILE HTML PREVIEW, NOT AN ANDROID APK.

IMPORTANT: This is NOT the Vehicle_Manager_Project_Transfer archive.
This ZIP has just three files, including the real mobile app preview.

STEPS
1. Open Samsung My Files > Downloads.
2. Find MileSage_Alpha_1_1_Mobile_Phone.zip.
3. Tap it, then Extract.
4. Open the new extracted folder.
5. Tap MileSage_Mobile.html and choose Chrome or Samsung Internet.
6. In MileSage, open Data & backup (near the top).
7. Tap Import from GitHub; confirm that you want to REPLACE old phone records.
8. Return to Home. Check BOTH cars show zero miles and there are zero service and fuel records.

If Import from GitHub fails, in MileSage tap Data & backup >
Choose JSON file, pick Alpha_1_1_Reset_vehicles.json from
this extracted folder, and confirm replacement.

PLEASE NOTE
- The phone's previous browser records might remain until you do step 7 or step 8.
- The app will NOT automatically upload your changes to GitHub.
- Keep an export backup when you begin entering new test data.
- Do not delete the extracted HTML file or old browser tabs may show FILE NOT FOUND.
- An installed app icon requires a future Android APK; this HTML preview does not install as an app.

GitHub repository: https://github.com/pmaylox/Vehicle-Management.io
