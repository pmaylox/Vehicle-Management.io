MileSage Alpha 1.3.6 - separate Android ALL UPDATES TEST build
Do NOT uninstall or clear the original MileSage APK; this is a separately installed TEST copy.
Back up your existing phone data before importing anything into the test copy.
The APK uses a new app ID and stores data SEPARATELY from the previously installed MileSage APK.
Use Data & backup > Import JSON file with YOUR full phone backup.
Confirm the real Tacoma and Explorer plus their histories after import.
This build combines Service-only multi-page PDF scanning with fixed Fuel autofill and 3-decimal US gallons.
Scan up to 30 service invoice pages; the scanner makes one PDF.
Tap Share / backup PDF in Service history; JSON backups do not include PDF bytes.
Test with disposable Service and Fuel records first; preserve original MileSage.
This APK is DEBUG-SIGNED for testing and not for production distribution.
Scanning, PDF opening/sharing and attachments require manual phone testing.
